# Build PhysioMaster APK using only an Android phone

This project includes a GitHub Actions workflow at `.github/workflows/android.yml` that builds a **debug APK** in the cloud. A debug APK is suitable for testing, not for publishing to Google Play.

## 1. Install a terminal app

Install Termux from its official F-Droid page: https://f-droid.org/packages/com.termux/

Open Termux and run:

```sh
termux-setup-storage
pkg update
pkg install git unzip
```

Allow file access when prompted. Put `PhysioMaster_Android_Project.zip` in your phone's `Download` folder.

## 2. Extract and prepare the project

In Termux, run:

```sh
cd ~/storage/downloads
unzip PhysioMaster_Android_Project.zip
cd PhysioMaster_Android_Project
git init
git add .
git commit -m "Add PhysioMaster Android project"
```

If Git asks for a name/email, set them with `git config --global user.name "Your Name"` and `git config --global user.email "you@example.com"`, then repeat the commit.

## 3. Create a private GitHub repository

In your phone browser, sign in at https://github.com/new . Create a repository named `PhysioMaster-Android`. Choose **Private** and do not add a README, .gitignore, or license. Copy the repository's HTTPS URL.

Back in Termux, replace `YOUR-USERNAME` with your GitHub username:

```sh
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/PhysioMaster-Android.git
git push -u origin main
```

GitHub may require authentication. Do not paste a password or access token into chat. If asked for a password, use a GitHub personal access token created in your GitHub account settings, and keep it private.

## 4. Download the APK

Open the repository on GitHub. Tap **Actions** → **Build PhysioMaster APK** → the latest successful run. Under **Artifacts**, download `PhysioMaster-debug-apk.zip`, extract it, and install `app-debug.apk`. If Android warns that the source is unknown, only continue if you trust the file you built yourself; enable permission for the browser/file manager temporarily and turn it off afterward.

## Important

- This produces a **debug/test APK**, not a signed Play Store release.
- A Play Store release requires a signed Android App Bundle (AAB), a protected signing key, and compliance checks.
- Quiz progress, coins, referral features and admin editing in this prototype are local/demo features. They are not a secure multi-user production backend; payments and real referral verification are not implemented.
