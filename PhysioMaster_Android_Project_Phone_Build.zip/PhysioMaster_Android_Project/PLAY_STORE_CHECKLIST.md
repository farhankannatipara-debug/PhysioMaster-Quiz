# Play Store launch checklist

- [ ] Final product name and branding confirmed
- [ ] 512×512 PNG app icon prepared
- [ ] Feature graphic and phone screenshots prepared
- [ ] Privacy policy URL published
- [ ] Data collection and Data safety form reviewed
- [ ] Content rating questionnaire completed
- [ ] Target audience and ads declarations completed accurately
- [ ] Digital goods billing reviewed against current Play policy
- [ ] Secure backend and admin authentication implemented
- [ ] Notes ownership/licensing verified
- [ ] Medical/educational disclaimer and support contact added
- [ ] Signed release AAB generated and signing key backed up
- [ ] Testing track requirements completed
- [ ] Store listing reviewed and submitted
